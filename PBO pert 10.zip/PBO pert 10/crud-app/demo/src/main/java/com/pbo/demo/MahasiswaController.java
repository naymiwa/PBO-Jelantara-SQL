
package com.pbo.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MahasiswaController {

    @Autowired
    private MahasiswaRepository mahasiswaRepository;

    @GetMapping("/mahasiswa")
    public List<Mahasiswa> tampilkanDataMahasiswa() {
        return mahasiswaRepository.findAll();
    }
}
