package com.pbo.demo;

public class CrudMahasiswa {
    
}
