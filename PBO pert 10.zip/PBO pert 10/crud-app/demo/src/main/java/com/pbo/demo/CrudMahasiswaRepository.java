package com.pbo.demo;

public class CrudMahasiswaRepository extends JpaRepository {
    
}
